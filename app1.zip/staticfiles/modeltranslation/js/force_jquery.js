if (typeof jQuery === 'undefined') {
  jQuery = django.jQuery;
}
